<form method="post" action="<?php echo e(url('regpost')); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="name"><br/>
    <input type="email" name="email"><br/>
    <input type="pasword" name="password"><br/>
    <button type="submit"></button>
</form><?php /**PATH C:\xamp\htdocs\newProject\resources\views/user/register.blade.php ENDPATH**/ ?>