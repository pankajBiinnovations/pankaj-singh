<?php if($errors->any()): ?>
    <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

<?php endif; ?>
<form action="<?php echo e(route('admin.handlelogin')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="email">
    <input type="password" name="password">
    <button type="submit">Login</button> 
</form><?php /**PATH C:\xamp\htdocs\newProject\resources\views/admin/login.blade.php ENDPATH**/ ?>