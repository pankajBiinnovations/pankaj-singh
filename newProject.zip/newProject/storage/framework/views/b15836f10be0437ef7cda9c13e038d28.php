<h1>Hello User </h1>

<a href="<?php echo e(url('addReview')); ?>">Review Management</a><br/>
<a href="<?php echo e(route('user.logout')); ?>">Logout</a><?php /**PATH C:\xamp\htdocs\newProject\resources\views/user/home.blade.php ENDPATH**/ ?>