<?php
$data=\App\Models\Product::all();
?>
<a href="<?php echo e(route('user.logout')); ?>">Logout</a>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>NAME</th>
            <th>IMAGE</th>
            <!-- Add more column headers as needed -->
        </tr>
    </thead>
    
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><img src="<?php echo e(asset('public/images/' . $item->image)); ?>" alt="Image">
</td>
<td>
<form id="reviewForm">
  
   <div class="form-group">
       <label for="comment">Comment:</label>
       <textarea name="comment" id="comment" rows="4" required></textarea>
   </div>
   <button type="submit">Submit</button>
</form>
</td>
                <!-- Add more table cells based on your data structure -->
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</table>


    
<a href="<?php echo e(url('myreview')); ?>">My Review</a>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Listen for form submission
    $('#reviewForm').submit(function(event) {
        event.preventDefault();

        // Get form data
        var formData = $(this).serialize();
        // Send AJAX request
        $.ajax({
            url: '<?php echo e(route('addReviewPost')); ?>',
            type: 'POST',
            data: formData,
            dataType: 'json',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            success: function(response) {
                // Handle successful response
                alert(response.message);
            },
            error: function(xhr, status, error) {
                // Handle error response
                console.log(xhr.responseText);
            }
        });
    });
</script>

<?php /**PATH C:\xamp\htdocs\newProject\resources\views/user/addReview.blade.php ENDPATH**/ ?>