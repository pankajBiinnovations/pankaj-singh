<h1>Hello Admin </h1>
<a href="<?php echo e(url('AdminManageReview')); ?>">Review Management</a><br/>
<a href="<?php echo e(route('admin.logout')); ?>">Logout</a><?php /**PATH C:\xamp\htdocs\newProject\resources\views/admin/home.blade.php ENDPATH**/ ?>