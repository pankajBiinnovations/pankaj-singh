<form action="<?php echo e(route('user.handlelogin')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="email">
    <input type="password" name="password">
    <button type="submit">Login</button> 
</form><?php /**PATH C:\xamp\htdocs\newProject\resources\views/user/login.blade.php ENDPATH**/ ?>