<h1>Hello Admin </h1>
<a href="{{url('AdminManageReview')}}">Review Management</a><br/>
<a href="{{route('admin.logout')}}">Logout</a>