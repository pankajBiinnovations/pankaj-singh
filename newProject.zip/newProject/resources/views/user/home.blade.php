<h1>Hello User </h1>

<a href="{{url('addReview')}}">Review Management</a><br/>
<a href="{{route('user.logout')}}">Logout</a>